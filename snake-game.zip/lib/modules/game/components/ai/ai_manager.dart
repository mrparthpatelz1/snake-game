import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/extensions.dart';
import 'package:flutter/material.dart';
import '../../../../data/models/food_model.dart';
import '../../views/game_screen.dart';
import '../food/food_manager.dart';
import '../player/player_component.dart';
import 'ai_snake_data.dart';

class AiManager extends Component with HasGameReference<SlitherGame> {
  final int numberOfSnakes = 100; // Reduced for better performance
  final Random _random = Random();
  final FoodManager foodManager;
  final PlayerComponent player;
  final List<AiSnakeData> snakes = [];

  late final List<Rect> _spawnZones;
  int _nextZoneIndex = 0;

  // Batched updates
  int _updateIndex = 0;
  static const int _batchSize = 8;

  AiManager({required this.foodManager, required this.player});

  @override
  Future<void> onLoad() async {
    super.onLoad();
    _initializeSpawnZones();
    _spawnAllSnakes();
  }

  // @override
  // void update(double dt) {
  //   super.update(dt);
  //
  //   final total = snakes.length;
  //   final end = _updateIndex + _batchSize;
  //
  //   for (int i = 0; i < total; i++) {
  //     final snake = snakes[i];
  //     if (i >= _updateIndex && i < end) {
  //       _updateActiveSnake(snake, dt);
  //     } else {
  //       _updatePassiveSnake(snake, dt);
  //     }
  //   }
  //
  //   _updateIndex = end % total;
  // }
  @override
  void update(double dt) {
    super.update(dt);

    // Expand visible area for smooth activation
    final visibleRect = game.cameraComponent.visibleWorldRect.inflate(400);

    int activeCount = 0;
    int passiveCount = 0;

    for (final snake in snakes) {
      if (visibleRect.overlaps(snake.boundingBox) || _isNearPlayer(snake, 600)) {
        // Snake is near screen → full AI update
        _updateActiveSnake(snake, dt);
        activeCount++;
      } else {
        // Snake is far away → super light update
        _lightPassiveUpdate(snake, dt);
        passiveCount++;
      }
    }
    debugPrint("Active snakes: $activeCount | Passive snakes: $passiveCount | Total: ${snakes.length}");
    _ensureMinActiveSnakes(dt);
  }

  void _ensureMinActiveSnakes(double dt) {
    final nearbySnakes = snakes.where((s) => _isNearPlayer(s, 800)).toList();

    // Force at least 15 active
    for (int i = 0; i < nearbySnakes.length && i < 15; i++) {
      _updateActiveSnake(nearbySnakes[i], dt);
    }
  }
  void _lightPassiveUpdate(AiSnakeData snake, double dt) {
    // Very slow movement for off-screen snakes
    const double speed = 40.0;
    final direction = Vector2(cos(snake.angle), sin(snake.angle));
    snake.position.add(direction * speed * dt);

    // Clamp to play area (avoid snakes drifting outside map)
    snake.position.clamp(
      SlitherGame.playArea.topLeft.toVector2(),
      SlitherGame.playArea.bottomRight.toVector2(),
    );

    // Skip body segments, food, and collisions to save CPU
  }

  bool _isNearPlayer(AiSnakeData snake, double range) {
    return snake.position.distanceTo(player.position) < range;
  }


  void _updatePassiveSnake(AiSnakeData snake, double dt) {
    // --- MOVEMENT from your old code ---
    const double speed = 120.0;
    const double segmentSpacing = 16.0 * 0.6;
    const double rotationSpeed = 2 * pi;

    // Rotate toward existing angle (no AI change for passive)
    final direction = Vector2(cos(snake.angle), sin(snake.angle));
    final move = direction * speed * dt;
    snake.position.add(move);

    // Clamp
    snake.position.clamp(
      SlitherGame.playArea.topLeft.toVector2(),
      SlitherGame.playArea.bottomRight.toVector2(),
    );

    // Body following
    Vector2 leader = snake.position;
    for (int i = 0; i < snake.bodySegments.length; i++) {
      final seg = snake.bodySegments[i];
      final dist = seg.distanceTo(leader);
      if (dist > segmentSpacing) {
        final dirToLeader = (leader - seg).normalized();
        seg.add(dirToLeader * (dist - segmentSpacing));
      }
      leader = seg;
    }
    // --- end old movement code ---

    // _updateBoundingBox(snake);
    // _checkFoodConsumption(snake);

    _enforceHardBoundaries(snake);
    _updateBoundingBox(snake);
    _checkFoodConsumption(snake);
  }

  void _updateActiveSnake(AiSnakeData snake, double dt) {
    _determineAiState(snake);
    _handleBoostLogic(snake, dt);

    // Decide rotation based on targetDirection
    final targetAngle = snake.targetDirection.screenAngle();
    const double rotationSpeed = 2 * pi;
    final angleDiff = _getAngleDifference(snake.angle, targetAngle);
    final rotationAmount = rotationSpeed * dt;
    if (angleDiff.abs() < rotationAmount) {
      snake.angle = targetAngle;
    } else {
      snake.angle += rotationAmount * angleDiff.sign;
    }

    // --- MOVEMENT from your old code ---
    const double speed = 120.0;
    const double segmentSpacing = 16.0 * 0.6;

    // Move head forward
    final direction = Vector2(cos(snake.angle), sin(snake.angle));
    snake.position.add(direction * speed * dt);

    // Clamp
    snake.position.clamp(
      SlitherGame.playArea.topLeft.toVector2(),
      SlitherGame.playArea.bottomRight.toVector2(),
    );

    // Body following
    Vector2 leader = snake.position;
    for (int i = 0; i < snake.bodySegments.length; i++) {
      final seg = snake.bodySegments[i];
      final dist = seg.distanceTo(leader);
      if (dist > segmentSpacing) {
        final dirToLeader = (leader - seg).normalized();
        seg.add(dirToLeader * (dist - segmentSpacing));
      }
      leader = seg;
    }
    // --- end old movement code ---

    // _updateBoundingBox(snake);
    // _checkFoodConsumption(snake);

    // _moveSnakeSmoothLikePlayer(snake, dt);
    // _updateSnakeBodyLikePlayer(snake, dt);
    _checkFoodConsumption(snake);
    _updateBoundingBox(snake);
  }

  // Smooth movement like player snake
  void _moveSnakeSmoothLikePlayer(AiSnakeData snake, double dt) {
    final input = snake.targetDirection;
    if (input != Vector2.zero()) {
      final targetAngle = input.screenAngle();
      const rotationSpeed = 4 * pi; // Slightly slower than player for realism
      final diff = _getAngleDifference(snake.angle, targetAngle);
      final turn = rotationSpeed * dt;
      snake.angle += diff.abs() < turn ? diff : turn * diff.sign;
    }

    // Move like player: direct movement based on direction
    final currentSpeed = snake.currentSpeed;
    snake.position.add(snake.targetDirection * currentSpeed * dt);

    _enforceHardBoundaries(snake);
  }

  // Body following like player snake
  void _updateSnakeBodyLikePlayer(AiSnakeData snake, double dt) {
    // 1) Determine new angle from targetDirection
    if (snake.targetDirection != Vector2.zero()) {
      final targetA = snake.targetDirection.screenAngle();
      final diff = _angleDiff(snake.angle, targetA);
      final turnRate = 3.0 * pi * dt; // tweak for slower/faster turning
      snake.angle += diff.abs() < turnRate ? diff : turnRate * diff.sign;
    }

    // 2) Move head along that angle
    final dx = sin(snake.angle) * snake.baseSpeed * dt;
    final dy = -cos(snake.angle) * snake.baseSpeed * dt;
    snake.position.add(Vector2(dx, dy));

    // 3) Record head pos to path
    snake.path.insert(0, snake.position.clone());
    if (snake.path.length > (snake.bodySegments.length + 5) * 20) {
      snake.path.removeRange((snake.bodySegments.length + 5) * 20, snake.path.length);
    }

    // 4) Use path for body
    for (int i = 0; i < snake.bodySegments.length; i++) {
      final dist = (i + 1) * snake.segmentSpacing;
      snake.bodySegments[i].setFrom(_pointOnPath(snake, dist));
    }
  }

  double _angleDiff(double a, double b) {
    var diff = (b - a + pi) % (2*pi) - pi;
    return diff < -pi ? diff + 2*pi : diff;
  }

  Vector2 _pointOnPath(AiSnakeData snake, double dist) {
    double acc=0;
    for(int i=0; i<snake.path.length-1; i++){
      final p1=snake.path[i], p2=snake.path[i+1];
      final segLen=p1.distanceTo(p2);
      if(acc+segLen>=dist){
        final t=(dist-acc)/segLen;
        return p1+(p2-p1)*t;
      }
      acc+=segLen;
    }
    return snake.path.last.clone();
  }

  Vector2 _getPointOnPathAtDistance(AiSnakeData snake, double distance) {
    final searchPath = [snake.position, ...snake.path];
    double distanceTraveled = 0;
    for (int i = 0; i < searchPath.length - 1; i++) {
      final p1 = searchPath[i];
      final p2 = searchPath[i + 1];
      final segmentLength = p1.distanceTo(p2);
      if (distanceTraveled + segmentLength >= distance) {
        final neededDist = distance - distanceTraveled;
        final direction = (p2 - p1).normalized();
        return p1 + direction * neededDist;
      }
      distanceTraveled += segmentLength;
    }
    return searchPath.last.clone();
  }

  double _getAngleDifference(double a, double b) {
    var diff = (b - a + pi) % (2 * pi) - pi;
    return diff < -pi ? diff + 2 * pi : diff;
  }

  void _handleBoostLogic(AiSnakeData snake, double dt) {
    if (snake.boostCooldownTimer > 0) {
      snake.boostCooldownTimer -= dt;
    }

    if (snake.isBoosting) {
      snake.boostDuration -= dt;
      if (snake.boostDuration <= 0 || snake.segmentCount <= 8) {
        snake.isBoosting = false;
        snake.boostCooldownTimer = 2.0;
      }
    }

    if (!snake.isBoosting && snake.boostCooldownTimer <= 0 && snake.segmentCount > 12) {
      final shouldBoost = _shouldSnakeBoost(snake);
      if (shouldBoost) {
        snake.isBoosting = true;
        snake.boostDuration = 1.0 + _random.nextDouble() * 1.5;
      }
    }
  }

  bool _shouldSnakeBoost(AiSnakeData snake) {
    switch (snake.aiState) {
      case AiState.chasing:
        final distToPlayer = snake.position.distanceTo(player.position);
        return distToPlayer < 300 && _random.nextDouble() < 0.4;

      case AiState.attacking:
        return _random.nextDouble() < 0.7;

      case AiState.fleeing:
      case AiState.defending:
        return _random.nextDouble() < 0.8;

      case AiState.avoiding_boundary:
        return _random.nextDouble() < 0.5;

      default:
        return _random.nextDouble() < 0.02;
    }
  }

  void _determineAiState(AiSnakeData snake) {
    final pos = snake.position;
    final bounds = SlitherGame.playArea;

    // Boundary avoidance priority
    if (!_isInsideBounds(pos, bounds.deflate(200))) {
      snake.aiState = AiState.avoiding_boundary;
      return;
    }

    // Check player distance and threat level
    final distToPlayer = pos.distanceTo(player.position);
    final playerRadius = player.playerController.headRadius.value;
    final playerSegments = player.bodySegments.length;

    if (distToPlayer < 120) {
      snake.aiState = AiState.defending;
      return;
    }

    // Combat logic
    if (distToPlayer < 400) {
      // Player is approaching - determine response
      if (snake.headRadius > playerRadius + 2) {
        // Snake is bigger - be aggressive
        snake.aiState = (Random().nextDouble() < 0.8)
            ? AiState.attacking
            : AiState.wandering; // sometimes fake retreat
        return;
      } else if (snake.headRadius < playerRadius - 2) {
        // Snake is smaller - flee or defend
        // Smaller snake → usually flee, sometimes defend
        snake.aiState = (distToPlayer < 200 && Random().nextDouble() < 0.3)
            ? AiState.defending
            : AiState.fleeing;
        return;
      } else {
        // Similar size - tactical decision
        if (snake.segmentCount > playerSegments + 5) {
          snake.aiState = AiState.chasing;
        } else if (snake.segmentCount < playerSegments - 5) {
          snake.aiState = AiState.defending;
        } else {
          snake.aiState = (Random().nextBool())
              ? AiState.wandering
              : AiState.attacking;
        }
        return;
      }
    }

    // Check for other AI snakes
    final nearbyThreats = _getNearbyThreats(snake);
    if (nearbyThreats.isNotEmpty) {
      final biggerThreat = nearbyThreats.any((t) => t.headRadius > snake.headRadius + 1);
      final smallerPrey = nearbyThreats.where((t) => t.headRadius < snake.headRadius - 1);

      if (biggerThreat) {
        snake.aiState = AiState.fleeing;
        return;
      } else if (smallerPrey.isNotEmpty && snake.segmentCount > 15) {
        snake.aiState = AiState.attacking;
        return;
      }
    }

    // Look for food
    final nearbyFood = _findNearestFood(pos, 300);
    if (nearbyFood != null) {
      snake.aiState = AiState.seeking_food;
      return;
    }

    // Default to wandering
    snake.aiState = AiState.wandering;
  }

  List<AiSnakeData> _getNearbyThreats(AiSnakeData snake) {
    final threats = <AiSnakeData>[];
    for (final other in snakes) {
      if (other == snake) continue;

      final distance = snake.position.distanceTo(other.position);
      if (distance < 250) {
        threats.add(other);
      }
    }
    return threats;
  }

  Vector2 _calculateTargetDirection(AiSnakeData snake) {
    switch (snake.aiState) {
      case AiState.avoiding_boundary:
        return _getBoundaryAvoidanceDirection(snake);
      case AiState.seeking_center:
        return _getCenterSeekingDirection(snake);
      case AiState.chasing:
        return _getChaseDirection(snake);
      case AiState.fleeing:
        return _getFleeDirection(snake);
      case AiState.attacking:
        return _getAttackDirection(snake);
      case AiState.defending:
        return _getDefendDirection(snake);
      case AiState.seeking_food:
        return _getFoodSeekingDirection(snake);
      case AiState.wandering:
        return _getWanderDirection(snake);
    }
  }

  Vector2 _getAttackDirection(AiSnakeData snake) {
    // Prioritize player if bigger than player
    final distToPlayer = snake.position.distanceTo(player.position);
    final playerRadius = player.playerController.headRadius.value;

    if (distToPlayer < 300 && snake.headRadius > playerRadius) {
      // Intercept player movement
      final playerVel = player.playerController.targetDirection;
      final interceptPoint = player.position + playerVel * 50;
      return (interceptPoint - snake.position).normalized();
    }

    // Attack smaller AI snakes
    final threats = _getNearbyThreats(snake);
    final smallerTargets = threats.where((t) => t.headRadius < snake.headRadius - 1);

    if (smallerTargets.isNotEmpty) {
      final target = smallerTargets.first;
      final interceptDir = Vector2(cos(target.angle), sin(target.angle));
      final interceptPoint = target.position + interceptDir * 80;
      return (interceptPoint - snake.position).normalized();
    }

    return _getWanderDirection(snake);
  }

  Vector2 _getDefendDirection(AiSnakeData snake) {
    // Defensive maneuvering - try to circle around threats
    final playerPos = player.position;
    final toPlayer = (playerPos - snake.position).normalized();

    // Move perpendicular to player approach
    final perpendicular = Vector2(-toPlayer.y, toPlayer.x);
    final defendDir = perpendicular * ((_random.nextDouble() - 0.5) * 2);

    // Also move away slightly
    final fleeComponent = (snake.position - playerPos).normalized() * 0.3;

    return (defendDir + fleeComponent).normalized();
  }

  Vector2 _getFoodSeekingDirection(AiSnakeData snake) {
    final food = _findNearestFood(snake.position, 300);
    if (food != null) {
      return (food.position - snake.position).normalized();
    }
    return _getWanderDirection(snake);
  }

  Vector2 _getBoundaryAvoidanceDirection(AiSnakeData snake) {
    final pos = snake.position;
    final b = SlitherGame.playArea;
    Vector2 force = Vector2.zero();
    const safe = 600.0;

    if (pos.x - b.left < safe) {
      final t = (safe - (pos.x - b.left)) / safe;
      force.x += t * t * 2;
    }
    if (b.right - pos.x < safe) {
      final t = (safe - (b.right - pos.x)) / safe;
      force.x -= t * t * 2;
    }
    if (pos.y - b.top < safe) {
      final t = (safe - (pos.y - b.top)) / safe;
      force.y += t * t * 2;
    }
    if (b.bottom - pos.y < safe) {
      final t = (safe - (b.bottom - pos.y)) / safe;
      force.y -= t * t * 2;
    }

    if (force.length < 0.1) {
      force = (Vector2.zero() - pos).normalized();
    }
    return force.normalized();
  }

  Vector2 _getCenterSeekingDirection(AiSnakeData snake) {
    final dir = (Vector2.zero() - snake.position).normalized();
    final rnd = Vector2(
      (_random.nextDouble() - 0.5) * 0.2,
      (_random.nextDouble() - 0.5) * 0.2,
    );
    return (dir + rnd).normalized();
  }

  Vector2 _getChaseDirection(AiSnakeData snake) {
    final toPlayer = (player.position - snake.position).normalized();
    final playerVel = player.playerController.targetDirection;
    final predPos = player.position + playerVel * 60.0;
    final toPred = (predPos - snake.position).normalized();
    return (toPlayer * 0.7 + toPred * 0.3).normalized();
  }

  Vector2 _getFleeDirection(AiSnakeData snake) {
    Vector2 fleeDir = Vector2.zero();

    // Flee from player
    final distToPlayer = snake.position.distanceTo(player.position);
    if (distToPlayer < 350) {
      fleeDir += (snake.position - player.position).normalized() * (350 - distToPlayer) / 350;
    }

    // Flee from bigger AI snakes
    final threats = _getNearbyThreats(snake).where((t) => t.headRadius > snake.headRadius);
    for (final threat in threats) {
      final distToThreat = snake.position.distanceTo(threat.position);
      if (distToThreat < 200) {
        fleeDir += (snake.position - threat.position).normalized() * (200 - distToThreat) / 200;
      }
    }

    if (fleeDir.length < 0.1) {
      fleeDir = (snake.position - player.position).normalized();
    }

    // Add evasive maneuvering
    final perpendicular = Vector2(-fleeDir.y, fleeDir.x);
    final evasion = perpendicular * ((_random.nextDouble() - 0.5) * 0.4);
    return (fleeDir + evasion).normalized();
  }

  Vector2 _getWanderDirection(AiSnakeData snake) {
    // Look for food first
    final food = _findNearestFood(snake.position, 250.0);
    if (food != null) {
      return (food.position - snake.position).normalized();
    }

    // Random direction changes
    if (_random.nextDouble() < 0.015) {
      final currentDir = Vector2(cos(snake.angle), sin(snake.angle));
      final turn = (_random.nextDouble() - 0.5) * pi * 0.6;
      final newDir = Vector2(
        currentDir.x * cos(turn) - currentDir.y * sin(turn),
        currentDir.x * sin(turn) + currentDir.y * cos(turn),
      );
      return newDir.normalized();
    }

    final currentDir = Vector2(cos(snake.angle), sin(snake.angle));
    final centerBias = (Vector2.zero() - snake.position).normalized() * 0.1;
    return (currentDir + centerBias).normalized();
  }

  void _updateBoundingBox(AiSnakeData snake) {
    double minX = snake.position.x, maxX = snake.position.x;
    double minY = snake.position.y, maxY = snake.position.y;
    for (final seg in snake.bodySegments) {
      minX = min(minX, seg.x);
      maxX = max(maxX, seg.x);
      minY = min(minY, seg.y);
      maxY = max(maxY, seg.y);
    }
    snake.boundingBox = Rect.fromLTRB(minX - 32, minY - 32, maxX + 32, maxY + 32);
  }

  void _enforceHardBoundaries(AiSnakeData snake) {
    final b = SlitherGame.playArea;

    if (snake.position.x < b.left) snake.position.x = b.left;
    if (snake.position.x > b.right) snake.position.x = b.right;
    if (snake.position.y < b.top) snake.position.y = b.top;
    if (snake.position.y > b.bottom) snake.position.y = b.bottom;

    final centerDir = (Vector2.zero() - snake.position).normalized();
    snake.targetDirection = centerDir;
    snake.angle = centerDir.screenAngle();
  }

  bool _isInsideBounds(Vector2 p, Rect r) =>
      p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;

  void _checkFoodConsumption(AiSnakeData snake) {
    final eR = snake.headRadius + 15;
    final eatRadiusSquared = eR * eR;

    final candidates = foodManager.foodList.where((food) {
      final distSquared = snake.position.distanceToSquared(food.position);
      return distSquared <= eatRadiusSquared;
    }).toList();

    for (final food in candidates) {
      foodManager.removeFood(food);
      _growSnake(snake, food.growth);
      foodManager.spawnFood();
    }
  }

  FoodModel? _findNearestFood(Vector2 p, double md) {
    FoodModel? nearest;
    double best = md * md;
    for (final f in foodManager.foodList) {
      final ds = p.distanceToSquared(f.position);
      if (ds < best) {
        nearest = f;
        best = ds;
      }
    }
    return nearest;
  }

  void _initializeSpawnZones() {
    const m = 300.0;
    final b = SlitherGame.worldBounds.deflate(m);
    final grid = (sqrt(numberOfSnakes)).ceil();
    final w = b.width / grid, h = b.height / grid;

    _spawnZones = List.generate(grid * grid, (i) {
      final r = i ~/ grid, c = i % grid;
      return Rect.fromLTWH(
        b.left + c * w,
        b.top + r * h,
        w,
        h,
      );
    })..shuffle(_random);
  }

  void _spawnAllSnakes() {
    for (int i = 0; i < numberOfSnakes; i++) {
      _spawnSnake();
    }
  }

  void _spawnSnake() {
    final zone = _spawnZones[_nextZoneIndex++ % _spawnZones.length];
    final x = zone.left + _random.nextDouble() * zone.width;
    final y = zone.top + _random.nextDouble() * zone.height;
    final pos = Vector2(x, y);

    final initCount = 12 + _random.nextInt(18); // 12-29 segments
    final baseSpeed = 60.0 + _random.nextDouble() * 25.0;

    final snakeData = AiSnakeData(
      position: pos,
      skinColors: _getRandomSkin(),
      targetDirection: Vector2.random(_random).normalized(),
      segmentCount: initCount,
      segmentSpacing: 13.0 * 0.6,
      baseSpeed: baseSpeed,
      boostSpeed: baseSpeed * 1.6,
      minRadius: 12.0,
      maxRadius: 40.0,
    );

    final bonus = (initCount / 25).floor().toDouble();
    snakeData.headRadius = (12.0 + bonus).clamp(snakeData.minRadius, snakeData.maxRadius);
    snakeData.bodyRadius = snakeData.headRadius - 1.0;

    // Initialize body segments and path
    snakeData.bodySegments.clear();
    snakeData.path.clear();
    for (int i = 0; i < initCount; i++) {
      final offset = snakeData.targetDirection * snakeData.segmentSpacing * (i + 1);
      final sPos = pos - offset;
      snakeData.bodySegments.add(sPos.clone());
      snakeData.path.add(sPos.clone());
    }

    snakeData.aiState = AiState.wandering;
    snakes.add(snakeData);
    _updateBoundingBox(snakeData);
  }

  void _growSnake(AiSnakeData snake, int amt) {
    final old = snake.segmentCount;
    snake.segmentCount += amt;
    for (int i = 0; i < amt; i++) {
      snake.bodySegments.add(snake.bodySegments.last.clone());
    }
    final oldB = (old / 25).floor();
    final newB = (snake.segmentCount / 25).floor();
    if (newB > oldB) {
      final inc = (newB - oldB).toDouble();
      snake.headRadius = (snake.headRadius + inc).clamp(snake.minRadius, snake.maxRadius);
      snake.bodyRadius = snake.headRadius - 1.0;
    }
  }

  void killSnakeAndScatterFood(AiSnakeData snake) {
    for (int i = 0; i < snake.bodySegments.length; i += 2) {
      foodManager.spawnFoodAt(snake.bodySegments[i]);
    }
    foodManager.spawnFoodAt(snake.position);
    snakes.remove(snake);
  }

  void spawnNewSnake() => _spawnSnake();

  List<Color> _getRandomSkin() {
    final base = _random.nextDouble() * 360;
    return List.generate(6, (i) {
      final h = (base + i * 15) % 360;
      return HSVColor.fromAHSV(1, h, 0.8, 0.9).toColor();
    });
  }
}
