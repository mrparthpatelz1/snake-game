import 'package:flame/components.dart';
import 'package:flutter/material.dart';

enum AiDifficulty { easy, medium, hard }

enum AiState {
  wandering,
  chasing,
  fleeing,
  avoiding_boundary,
  seeking_center,
  attacking,
  seeking_food,
  defending       // New: defensive behavior
}

class AiSnakeData {
  Vector2 position;
  double angle = 0.0;
  final List<Vector2> bodySegments = [];
  final List<Color> skinColors;
  Vector2 targetDirection;
  final List<Vector2> path = [];  // For smooth body following like player

  Rect boundingBox = Rect.zero;

  double headRadius = 0;
  double bodyRadius = 0;
  final double segmentSpacing;

  // Speed properties
  double baseSpeed;
  double boostSpeed;

  // Boost mechanics
  bool isBoosting = false;
  double boostDuration = 0.0;
  double boostCooldownTimer = 0.0;

  int segmentCount;
  final double minRadius;
  double maxRadius;

  late AiDifficulty difficulty;
  late AiState aiState;

  AiSnakeData({
    required this.position,
    required this.skinColors,
    required this.targetDirection,
    required this.segmentSpacing,
    required this.baseSpeed,
    required this.boostSpeed,
    required this.segmentCount,
    required this.minRadius,
    required this.maxRadius,
  }) {
    aiState = AiState.wandering;
    difficulty = AiDifficulty.medium;
  }

  double get currentSpeed => isBoosting ? boostSpeed : baseSpeed;
  bool get canBoost => segmentCount > 12 && boostCooldownTimer <= 0 && !isBoosting;
}
