import 'dart:math';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'ai_manager.dart';

class AiPainter extends PositionComponent with HasGameRef {
  final AiManager aiManager;
  final CameraComponent cameraToFollow;

  final Paint _eyePaint = Paint()..color = Colors.white;
  final Paint _pupilPaint = Paint()..color = Colors.black;

  AiPainter({required this.aiManager, required this.cameraToFollow});

  // @override
  // void render(Canvas canvas) {
  //   super.render(canvas);
  //   final visibleRect = cameraToFollow.visibleWorldRect;
  //
  //   for (final snake in aiManager.snakes) {
  //     if (!visibleRect.overlaps(snake.boundingBox)) continue;
  //
  //     // Draw body segments
  //     for (int i = snake.bodySegments.length - 1; i >= 0; i--) {
  //       final segPos = snake.bodySegments[i];
  //       final color = snake.skinColors[i % snake.skinColors.length];
  //       _drawSegment(canvas, segPos, snake.bodyRadius, color);
  //     }
  //
  //     // Draw head
  //     final headColor = snake.skinColors.first;
  //     _drawSegment(canvas, snake.position, snake.headRadius, headColor);
  //     _drawEyes(canvas, snake.position, snake.angle, snake.headRadius);
  //   }
  // }
  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final visibleRect = cameraToFollow.visibleWorldRect.inflate(50);
    // margin = 100px so they appear smoothly
    int renderedCount = 0;

    for (final snake in aiManager.snakes) {
      if (!visibleRect.overlaps(snake.boundingBox)) {
        continue; // Skip rendering far-away snakes
      }
      renderedCount++;
      // Draw body segments
      for (int i = snake.bodySegments.length - 1; i >= 0; i--) {
        final segPos = snake.bodySegments[i];
        final color = snake.skinColors[i % snake.skinColors.length];
        _drawSegment(canvas, segPos, snake.bodyRadius, color);
      }

      // Draw head + eyes
      final headColor = snake.skinColors.first;
      _drawSegment(canvas, snake.position, snake.headRadius, headColor);

      _drawEyes(canvas, snake.position, snake.angle, snake.headRadius);

    }
      debugPrint("Rendered snakes: $renderedCount");
  }


  void _drawSegment(Canvas canvas, Vector2 position, double radius, Color color) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [color, color.withOpacity(0.5)],
      ).createShader(Rect.fromCircle(center: Offset(position.x, position.y), radius: radius));
    canvas.drawCircle(Offset(position.x, position.y), radius, paint);
  }

  void _drawEyes(Canvas canvas, Vector2 headPosition, double headAngle, double headRadius) {
    final eyeRadius = headRadius * 0.25;
    final pupilRadius = eyeRadius * 0.5;
    final eyeDistance = headRadius * 0.6;

    final rightEyePos = headPosition + Vector2(cos(headAngle + pi / 4) * eyeDistance, sin(headAngle + pi / 4) * eyeDistance);
    canvas.drawCircle(Offset(rightEyePos.x, rightEyePos.y), eyeRadius, _eyePaint);
    canvas.drawCircle(Offset(rightEyePos.x, rightEyePos.y), pupilRadius, _pupilPaint);

    final leftEyePos = headPosition + Vector2(cos(headAngle - pi / 4) * eyeDistance, sin(headAngle - pi / 4) * eyeDistance);
    canvas.drawCircle(Offset(leftEyePos.x, leftEyePos.y), eyeRadius, _eyePaint);
    canvas.drawCircle(Offset(leftEyePos.x, leftEyePos.y), pupilRadius, _pupilPaint);
  }
}
